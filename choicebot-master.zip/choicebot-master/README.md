# Choicebot v1.2
## Author: github.com/cyberkallan/choicebot
## IG: Instagram.com/arz_beats
### Don't copy this code without give me the credits, bitch! 
Choicebot is a bot written in Shell Script (the first one) to perform 'likes', 'comments' and 'follows' based on hastags.

![choice](https://user-images.githubusercontent.com/56509491/66764160-d2daca00-eec6-11e9-98b3-605d315931da.JPG)

### Usage:
```
git clone https://github.com/cyberkallan/choicebot
cd choicebot
chmod +x choicebot.sh
nano hashtags.txt (put your hashtags here)
./choicebot.sh
```

### Install requirements (Curl):

```
apt-get install curl
```

# arjun arz
![cb](https://user-images.githubusercontent.com/56509491/66750279-b2504700-eea9-11e9-9f9e-100ddc35504c.jpg)

### Donate!
Support the authors:

<noscript><a href="https://liberapay.com/thelinuxchoice/donate"><img alt="Donate using Liberapay" src="https://liberapay.com/assets/widgets/donate.svg"></a></noscript>
